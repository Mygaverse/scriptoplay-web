module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // If using Tailwind v4
    // OR if using v3: 'tailwindcss': {}, 
    // 'autoprefixer': {},
  },
};