"use client";  // <--- THIS MUST BE LINE 1


const FeaturesGeneration = () => {
  return (
    <section id="generation" className="py-24 bg-gray-50 dark:bg-white text-gray-900">
      <div className="main-container max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-xl border border-[#a22070] text-[#a22070] text-sm font-medium mb-4 tracking-wider">
            Exclusive Features: Generation
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-black">Generate Your Script with AI Precision</h2>
          <p className="max-w/90 mx-auto text-lg font-medium text-gray ">
            Scriptoplay’s generation engine helps you go from a spark of inspiration to a fully structured screenplay. Whether you're brainstorming ideas, drafting scenes, or polishing the narrative tone, our AI-driven tools support your flow with creative guidance, structural logic, and cinematic formatting.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard 
            title="Genre-Aware Copilot"
            desc="Whether it's thriller, drama, or rom-com, our AI adjusts tone, pacing, and structure to match industry standards."
            
            visual={<div className="h-32 bg-gray-200 rounded-lg w-full flex items-center justify-center"><div className="bg-[#a22070] text-white px-4 py-1 rounded text-sm shadow-lg">Action Sci-Fi</div></div>}
          />
          <FeatureCard 
            title="Idea & Scene Generator"
            desc="Start with an idea or logline and let our AI guide you through plot development, scene structuring, and character dialogue."
            
            visual={<div className="h-32 bg-gray-200 rounded-lg w-full p-3 grid grid-cols-2 gap-2"><div className="bg-white rounded shadow-sm"></div><div className="bg-white rounded shadow-sm"></div></div>}
          />
          <FeatureCard 
            title="AI-Assisted Formatting"
            desc="Automatically format your scripts to industry standards with better rhythm, emotion, or tone based on your intent."
            
            visual={<div className="h-32 bg-gray-200 rounded-lg w-full flex items-center justify-center text-gray-400 text-xs font-mono">Scanning...</div>}
          />
        </div>
      </div>
    </section>
  );
};

const FeatureCard = ({ title, desc, visual, icon }: any) => (
  <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
    <div className="mb-6">{visual}</div>
    <div className="flex items-center gap-2 mb-2">
        
        <h3 className="text-xl font-bold">{title}</h3>
    </div>
    <p className="text-gray-500 text-md leading-relaxed">{desc}</p>
  </div>
);

export default FeaturesGeneration;