"use client";  // <--- THIS MUST BE LINE 1

const FeaturesEvaluation = () => {
  return (
    <section id="evaluation" className="py-24 bg-white text-gray-900 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-xl border border-[#a22070] text-[#a22070] text-sm font-medium mb-4 tracking-wider">
            Exclusive Features: Evaluation
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-black">Evaluate Your Script with Confidence</h2>
          <p className="max-w/90 mx-auto text-lg font-medium text-gray ">
            Get beyond spell checks. Scriptoplay’s evaluation engine delivers intelligent feedback on structure, pacing, dialogue, and character arcs — helping you fine-tune your work before sending it to readers, agents, or producers.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
           <div className="bg-gray-50 border border-gray-100 p-8 rounded-2xl hover:border-gray-200 shadow-lg transition-colors hover:shadow-xl transition-shadow duration-300">
              <div className="h-56 bg-gray-200 rounded-lg mb-6 flex items-center justify-center relative overflow-hidden">
                  <div className="bg-black/80 backdrop-blur-sm px-6 py-3 rounded-xl flex items-center justify-center shadow-2xl">
                    <span className="text-4xl font-bold text-fuchsia-400">48.9%</span>
                  </div>
              </div>
              <div className="flex items-center gap-2 mb-2">
                
                <h3 className="text-xl font-bold">Script Evaluation with Score Feedback</h3>
              </div>
              <p className="text-gray-500 text-md leading-relaxed">Receive detailed evaluations across categories like plot coherence, dialogue strength, character development, and pacing — all backed by AI-driven scoring and narrative metrics.</p>
           </div>
           
           <div className="bg-gray-50 border border-gray-100 p-8 rounded-2xl hover:border-gray-200 shadow-lg transition-colors hover:shadow-xl transition-shadow duration-300">
              <div className="h-56 bg-gray-200 rounded-lg mb-6 grid grid-cols-3 gap-3 p-6 items-end">
                 <div className="bg-white/50 rounded h-12 w-full"></div>
                 <div className="bg-fuchsia-600 rounded h-32 w-full shadow-lg"></div>
                 <div className="bg-white/50 rounded h-20 w-full"></div>
              </div>
              <div className="flex items-center gap-2 mb-2">
                
                <h3 className="text-xl font-bold">Script Insights Dashboard & Reports</h3>
              </div>
              <p className="text-gray-500 text-md leading-relaxed">Visualize your script’s structure, emotional rhythm, and act balance. Track improvements with version comparisons and export shareable feedback reports.</p>
           </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesEvaluation;