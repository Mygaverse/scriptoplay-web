import { UserGroupIcon, TaskIcon, MessageIcon } from "@/icons";

const About = () => {
  return (
    <section id="about" className="py-24 bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 text-center">
         {/* Badge */}
        <span className="inline-block px-4 py-2 rounded-xl border border-[#a22070]/50 bg-gray-950 text-gray-400 text-sm font-medium mb-4 tracking-wider">
            About
        </span>
        <h2 className="text-5xl text-white font-semibold mb-4">Improves the Success Rate</h2>
        <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-16">
            Scriptoplay is more than just a writing tool — it’s a creative partner for screenwriters. Designed by storytellers, powered by AI, and built for impact, we help bring scripts closer to the screen with clarity, quality, and confidence.
        </p>

        <div className="grid md:grid-cols-3 gap-6 text-left">
            <AboutCard 
                icon={<MessageIcon />}
                title="Built for Writers, Backed by AI"
                desc="We blend creative intuition with cutting-edge technology, so writers can focus on storytelling while our AI handles structure, feedback, and optimization."
            />
            <AboutCard 
                icon={<TaskIcon />}
                title="Full Workflow Coverage"
                desc="From idea generation to script polishing and insight reporting, Scriptoplay supports your writing journey end-to-end — all in one seamless platform."
            />
            <AboutCard 
                icon={<UserGroupIcon />}
                title="Industry-Ready Results"
                desc="Our formatting, scoring, and evaluation tools are aligned with professional screenwriting standards — helping your script shine."
            />
        </div>
      </div>
    </section>
  );
};

const AboutCard = ({ icon, title, desc }: any) => (
    <div className="bg-[#111] p-8 rounded-2xl border border-white/10 hover:border-white/20 transition-all group hover:-translate-y-1">
        <div className="w-10 h-10 bg-white/5 rounded flex items-center justify-center mb-6 group-hover:bg-white/10 transition-colors">
            {icon}
        </div>
        <h3 className="text-xl font-bold mb-3 text-white">{title}</h3>
        <p className="text-gray-500 text-md leading-relaxed">{desc}</p>
    </div>
);

export default About;